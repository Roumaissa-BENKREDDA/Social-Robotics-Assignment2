<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Book for later</name>
        <message>
            <source>Okey, you want to book a table for lunch or dinner?</source>
            <comment>Text</comment>
            <translation type="obsolete">Okey, you want to book a table for lunch or dinner?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Greeting</name>
        <message>
            <source>Hello, welcome to our restaurant. My name is pepper and I am here to assist you!</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello, welcome to our restaurant. My name is pepper and I am here to assist you!</translation>
        </message>
        <message>
            <source>Hello, welcome to our restaurant. My name is pepper and I am here to assist you in your table reservation.</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello, welcome to our restaurant. My name is pepper and I am here to assist you in your table reservation.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hello, welcome to our restaurant. My name is pepper and I am here to assist you.</source>
            <comment>Text</comment>
            <translation type="unfinished">Hello, welcome to our restaurant. My name is pepper and I am here to assist you.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/dinner</name>
        <message>
            <source>Follow me, to show you your table.</source>
            <comment>Text</comment>
            <translation type="obsolete">Follow me, to show you your table.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Okey, so you want to book for dinner</source>
            <comment>Text</comment>
            <translation type="unfinished">Okey, so you want to book for dinner</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/lunch</name>
        <message>
            <source>Okey, so you want to book for dinner</source>
            <comment>Text</comment>
            <translation type="obsolete">Okey, so you want to book for dinner</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Okey, so you want to book for lunch</source>
            <comment>Text</comment>
            <translation type="unfinished">Okey, so you want to book for lunch</translation>
        </message>
    </context>
</TS>
