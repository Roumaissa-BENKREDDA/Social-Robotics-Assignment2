<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Okey, you find the menu here, call me when you decide what to eat</source>
            <comment>Text</comment>
            <translation type="unfinished">Okey, you find the menu here, call me when you decide what to eat</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Assistance</name>
        <message>
            <source>I am pepper, how can I assist you?</source>
            <comment>Text</comment>
            <translation type="obsolete">I am pepper, how can I assist you?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Book for later</name>
        <message>
            <source>Okey, you want to book a table for lunch or dinner?</source>
            <comment>Text</comment>
            <translation type="obsolete">Okey, you want to book a table for lunch or dinner?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Eat here !</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Follow me, to show you your table.</source>
            <comment>Text</comment>
            <translation type="unfinished">Follow me, to show you your table.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Greeting</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hello, welcome to our restaurant.</source>
            <comment>Text</comment>
            <translation type="unfinished">Hello, welcome to our restaurant.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Take away !</name>
        <message>
            <source>Okey, here you find the menu.</source>
            <comment>Text</comment>
            <translation type="obsolete">Okey, here you find the menu.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Okey, follow me to show you the menu.</source>
            <comment>Text</comment>
            <translation type="unfinished">Okey, follow me to show you the menu.</translation>
        </message>
    </context>
</TS>
